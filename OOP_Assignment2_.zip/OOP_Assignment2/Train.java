import java.util.Scanner;

public class Train {
    Scanner reader = new Scanner(System.in);
    private String Name;
    public void nameOfTrain() { System.out.println(Name = reader.next() + " is going places" + System.lineSeparator() + "Stats of each Wagon:"); }
} //reads train name and outputs some funny lines
