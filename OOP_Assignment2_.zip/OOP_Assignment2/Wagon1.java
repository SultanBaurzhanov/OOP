public class Wagon1 extends Train {
    private int wagonID = 1;
    private String type = "VIP";
    private String speed = "40m/s";
    private String time = "3 hours";
    public int Capacity = 10;

    public void getStats() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity + "\n");
    } //prints out every stat
}
