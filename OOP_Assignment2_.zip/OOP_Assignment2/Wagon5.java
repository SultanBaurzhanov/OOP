public class Wagon5 extends Train {
    private int wagonID = 5;
    private String type = "forDG";   //for disabled guests
    private String speed = "70m/s";
    private String time = "2.0 hours";
    public int Capacity = 10;

    public void getStats() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
