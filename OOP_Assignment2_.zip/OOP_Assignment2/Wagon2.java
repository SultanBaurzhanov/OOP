public class Wagon2 extends Train {
    private int wagonID = 1;
    private String type = "VIP";
    private String speed = "40m/s";
    private String time = "2.5 hours";
    public int Capacity = 15;

    public void getStats() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
