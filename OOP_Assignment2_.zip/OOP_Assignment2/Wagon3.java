public class Wagon3 extends Train {
    private int wagonID = 3;
    private String type = "Regular";
    private String speed = "70m/s";
    private String time = "2.0 hours";
    public int Capacity = 20;

    public void getStats() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
