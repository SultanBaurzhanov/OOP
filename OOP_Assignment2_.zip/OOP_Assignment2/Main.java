import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        Train train = new Train(); //create train and wagons
        Wagon1 wagon1 = new Wagon1();
        Wagon2 wagon2 = new Wagon2();
        Wagon3 wagon3 = new Wagon3();
        Wagon4 wagon4 = new Wagon4();
        Wagon5 wagon5 = new Wagon5();

        train.nameOfTrain(); //output train stuff and some funny stats of each wagon
        wagon1.getStats();
        wagon2.getStats();
        wagon3.getStats();
        wagon4.getStats();
        wagon5.getStats();

    }
}
