public class ListCommand implements Command {
    @Override
    public void execute() {
        List.getList();
    }
}