import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);

        Train train = new Train(); //create train and wagons
        Wagon1 wagon1 = new Wagon1();
        Wagon2 wagon2 = new Wagon2();
        Wagon3 wagon3 = new Wagon3();
        Wagon4 wagon4 = new Wagon4();
        Wagon5 wagon5 = new Wagon5();

        train.nameOfTrain(); //output train stuff and some funny stats of each wagon
        System.out.println("Type stats of each Wagon from 1 to 5:");
        String A = sc.nextLine(); //gives stats based on numbers from 1 - 5, those are wagon IDS
        if (A.equals("1")) {
            wagon1.getStats1();
        } else if (A.equals("2")) {
            wagon2.getStats2();
        } else if (A.equals("3")) {
            wagon3.getStats3();
        } else if (A.equals("4")) {
            wagon4.getStats4();
        } else if (A.equals("5")) {
            wagon5.getStats5();
        }
    }
}