public class Wagon3 extends Train {
    private int wagonID = 3;
    private String type = "Econom, lol";
    private String speed = "50m/s";
    private String time = "24 hours";
    private int Capacity = 20;

    public void getStats3() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
