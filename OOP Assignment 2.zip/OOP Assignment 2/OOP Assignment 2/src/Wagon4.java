public class Wagon4 extends Train {
    private int wagonID = 4;
    private String type = "Extra econom, I dunno";
    private String speed = "30m/s";
    private String time = "2 days";
    private int Capacity = 20;

    public void getStats4() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
