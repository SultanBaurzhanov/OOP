public class Wagon5 extends Train {
    private int wagonID = 5;
    private String type = "Bar or something, maybe staff";
    private String speed = "30m/s";
    private String time = "7 days";
    private int Capacity = 10;

    public void getStats5() {
        System.out.println("Wagon ID: " + wagonID + System.lineSeparator() + "Type: " + type + System.lineSeparator() + "Speed: " + speed + System.lineSeparator() + "Time: " + time + System.lineSeparator() + "Capacity: " + Capacity);
    } //prints out every stat
}
